#!/usr/bin/env python3

def main():
    print('Welcome to the Brain Games!')
    from brain_games import cli

if __name__ == '__main__':
    main()
    welcome_user()
