<a href="https://codeclimate.com/github/Korvo-iam/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/1d71d580ba31029ddb01/maintainability" /></a>
