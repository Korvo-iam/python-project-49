https://asciinema.org/a/4nnp6za0lArfEbadYbwxTlmjd
