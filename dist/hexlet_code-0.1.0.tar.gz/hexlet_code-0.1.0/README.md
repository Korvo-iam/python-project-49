<a href="https://codeclimate.com/github/Korvo-iam/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/1d71d580ba31029ddb01/maintainability" /></a>

https://github.com/Korvo-iam/python-project-49/actions

[![asciicast](https://asciinema.org/a/rj9vcHsh2DcGAdqIM8VTUp1ys.svg)](https://asciinema.org/a/rj9vcHsh2DcGAdqIM8VTUp1ys)
