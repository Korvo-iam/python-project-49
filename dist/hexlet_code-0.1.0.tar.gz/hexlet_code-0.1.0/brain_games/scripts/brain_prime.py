from brain_games.games import game_prime as game
from brain_games import default


def main():
    default.start_def(game)


if __name__ == '__main__':
    main()
